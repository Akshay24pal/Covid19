(function($) {
  'use strict';

  $(function() {
		
    $('[data-toggle="offcanvas"]').on("click", function() e

      $('.sidebar-offcanvas').toggleClass('active')
    });
  });
})(jQuery);