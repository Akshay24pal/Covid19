export const constants = {
    apiBaseURL: 'https://coronavirus-monitor.p.rapidapi.com/coronavirus/', 
};
