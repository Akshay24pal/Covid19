import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { constants } from '../utils/constants';


@Injectable({
  providedIn: 'root'
})
export class CommonService {
  constructor(public http: HttpClient) { }

  /*function for calling get Apis's*/
  get(url) {
    let headers = new HttpHeaders()
    headers = headers.append("x-rapidapi-host", "coronavirus-monitor.p.rapidapi.com")
    headers = headers.append("x-rapidapi-key", "e7cbe2b1e2msh5a73e58499721bbp18dec4jsn5e92afb4e259")
    headers = headers.append("useQueryString", "true")
    const finalUrl = constants.apiBaseURL + url;
    return this.http.get<any[]>(finalUrl, { 'headers': headers }).pipe(
      map((data) => {
        //You can perform some transformation here
        return data;
      }),
      catchError((err) => {
        console.error(err);
        throw err;
      })
    )
  }

  

}
