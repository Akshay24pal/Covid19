import { Component, OnInit } from '@angular/core';
import {CommonService} from '../../core/services/common.service'

@Component({
  selector: 'app-country-cases',
  templateUrl: './country-cases.component.html',
  styleUrls: ['./country-cases.component.css']
})
export class CountryCasesComponent implements OnInit {

  countryName:string=''
  countryData:any={};
  constructor(private commonService:CommonService) { }

  ngOnInit(): void {
   
  }

  search()
  {
    if(this.countryName.length>0){
      this.commonService.get("latest_stat_by_country.php?country="+this.countryName)
      .subscribe((data: any)=>{
        this.countryData=data;
        console.log( this.countryData)
      },
      (error) => {                             
        console.log('error',error);
      });
    }else{
      alert("Enter Country Name")
    }
  }

}
